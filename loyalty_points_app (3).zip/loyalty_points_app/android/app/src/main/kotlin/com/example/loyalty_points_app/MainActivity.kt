package com.example.loyalty_points_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
