import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:loyalty_points_app/provider/app_provider.dart';
import 'package:loyalty_points_app/provider/user_provider.dart';
import 'package:loyalty_points_app/widgets/common.dart';
import 'package:loyalty_points_app/widgets/custom_text.dart';
import 'package:loyalty_points_app/widgets/loading.dart';
import 'package:loyalty_points_app/widgets/small_button.dart';
import 'package:provider/provider.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';
import 'package:loyalty_points_app/widgets/partials.dart';
import 'cart.dart';

class Electronics extends StatefulWidget {
  @override
  _ElectronicsState createState() => _ElectronicsState();
}

class _ElectronicsState extends State<Electronics> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.black,
          actions: <Widget>[],
          elevation: 0.0,
          title: Text("Electronics"),
        ),
        body: ListPage());
  }
}

class ListPage extends StatefulWidget {
  @override
  _ListPageState createState() => _ListPageState();
}

class _ListPageState extends State<ListPage> {
  Future _data;

  Future getUsers() async {
    var firestore = Firestore.instance;
    QuerySnapshot qn = await firestore.collection('electronics').getDocuments();
    return qn.documents;
  }

  @override
  void initState() {
    super.initState();

    _data = getUsers();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: FutureBuilder(
        future: _data,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: Text('Loading...'),
            );
          } else {
            return ListView.builder(
                itemCount: snapshot.data.length,
                itemBuilder: (_, index) {
                  return Padding(
                      padding: EdgeInsets.fromLTRB(12, 14, 16, 12),
                      child: GestureDetector(
                        onTap: () => navigateToDetail(snapshot.data[index]),
                        child: Container(
                          height: 220,
                          width: 190,
                          decoration: BoxDecoration(
                              color: white,
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.grey[300],
                                    offset: Offset(-2, -1),
                                    blurRadius: 5),
                              ]),
                          child: Column(
                            children: <Widget>[
                              ClipRRect(
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(10),
                                    topRight: Radius.circular(20)),
                                child: Stack(
                                  children: <Widget>[
                                    // Positioned.fill(
                                    //     child: Align(
                                    //   alignment: Alignment.center,
                                    //   child: Loading(),
                                    // )),
                                    Padding(
                                      padding: const EdgeInsets.all(10.0),
                                      child: Center(
                                        child: Image.network(
                                          snapshot.data[index].data['image'],
                                          height: 120,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: <Widget>[
                                  Flexible(
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: CustomText(
                                        text: snapshot.data[index].data['name'],
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.all(8),
                                    child: GestureDetector(
                                      onTap: () {
//                                  setState(() {
//                                    productProvider.products[index].liked = !productProvider.products[index].liked;
//                                  });
//                                  productProvider.likeDislikeProduct(userId: user.userModel.id, product: productProvider.products[index], liked: productProvider.products[index].liked);
                                      },
                                      child: Container(),
                                    ),
                                  )
                                ],
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: <Widget>[
                                  Row(
                                    children: <Widget>[
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(left: 8.0),
                                        child: CustomText(
                                          text: snapshot
                                              .data[index].data['name']
                                              .toString(),
                                          color: grey,
                                          size: 14.0,
                                        ),
                                      ),
                                      SizedBox(
                                        width: 2,
                                      ),
                                      Icon(
                                        Icons.star,
                                        color: red,
                                        size: 16,
                                      ),
                                      Icon(
                                        Icons.star,
                                        color: red,
                                        size: 16,
                                      ),
                                      Icon(
                                        Icons.star,
                                        color: red,
                                        size: 16,
                                      ),
                                      Icon(
                                        Icons.star,
                                        color: grey,
                                        size: 16,
                                      ),
                                    ],
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(right: 8.0),
                                    child: CustomText(
                                      text:
                                          "\R ${snapshot.data[index].data['price'] / 1}",
                                      weight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ));
//                   return Container(
//                     height: 100,
//                     child: Card(
//                       margin: EdgeInsets.all(10),
//                       color: Colors.white,
//                       child: Padding(
//                         padding: const EdgeInsets.all(10),
//                         child: ListTile(
//                           leading: CircleAvatar(
//                             radius: 20.0,
// //                            child: Text(snapshot.data[index].data['companyName'][0].toUpperCase()),
//                             backgroundImage: NetworkImage(
//                                 snapshot.data[index].data['image']),
//                           ),
//                           title: Text(snapshot.data[index].data['name']),
//                           onTap: () => navigateToDetail(snapshot.data[index]),
//                         ),
//                       ),
//                     ),
//                   );
                });
          }
        },
      ),
    );
  }

  navigateToDetail(DocumentSnapshot post) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => DetailPage(
                  post: post,
                )));
  }
}

class DetailPage extends StatefulWidget {
  final DocumentSnapshot post;
  DetailPage({this.post});
  @override
  _DetailPageState createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  int quantity = 1;
  double rating = 4;
  final _key = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserProvider>(context);
    final app = Provider.of<AppProvider>(context);
    return Scaffold(
        key: _key,
        backgroundColor: bgColor,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: bgColor,
          centerTitle: true,
          leading: BackButton(
            color: darkText,
          ),
          title: Text(widget.post.data['name'], style: h4),
          actions: <Widget>[
            IconButton(
              icon: Icon(
                Icons.shopping_cart,
                color: primaryColor,
              ),
              onPressed: () {
                changeScreen(context, CartScreen());
              },
            ),
          ],
        ),
        body: ListView(
          children: <Widget>[
            Container(
              margin: EdgeInsets.only(top: 10),
              child: Center(
                child: Stack(
                  children: <Widget>[
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                        margin: EdgeInsets.only(top: 100, bottom: 100),
                        padding: EdgeInsets.only(top: 100, bottom: 50),
                        width: MediaQuery.of(context).size.width * 0.85,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
//                            Image.network(widget.product.image),
                            SizedBox(
                              height: 10,
                            ),
                            Text(widget.post.data['name'], style: h5),
                            Text("\R ${widget.post.data['price'] / 1}",
                                style: h3),
                            Container(
                              margin: EdgeInsets.only(top: 5, bottom: 20),
                              child: SmoothStarRating(
                                allowHalfRating: false,
                                onRatingChanged: (v) {
                                  setState(() {
                                    rating = v;
                                  });
                                },
                                starCount: 5,
                                rating: rating,
                                size: 27.0,
                                color: Colors.orange,
                                borderColor: Colors.orange,
                              ),
                            ),
                            Container(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text(
                                    "Details",
                                    style: h4,
                                  ),
                                  Container(
                                    padding: EdgeInsets.all(20),
                                    child: Center(
                                        child: Text(
                                      widget.post.data['description'],
                                      textAlign: TextAlign.center,
                                      style: inputFieldTextStyle,
                                    )),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 10, bottom: 25),
                              child: Column(
                                children: <Widget>[
                                  Container(
                                    child: Text('Quantity', style: h6),
                                    margin: EdgeInsets.only(bottom: 15),
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: <Widget>[
                                      Container(
                                        width: 55,
                                        height: 55,
                                        child: OutlineButton(
                                          onPressed: () {
                                            setState(() {
                                              quantity += 1;
                                            });
                                          },
                                          child: Center(child: Icon(Icons.add)),
                                        ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.only(
                                            left: 20, right: 20),
                                        child: Text(quantity.toString(),
                                            style: h3),
                                      ),
                                      Container(
                                        width: 55,
                                        height: 55,
                                        child: OutlineButton(
                                          onPressed: () {
                                            setState(() {
                                              if (quantity == 1) return;
                                              quantity -= 1;
                                            });
                                          },
                                          child: Icon(Icons.remove),
                                        ),
                                      )
                                    ],
                                  )
                                ],
                              ),
                            ),
                            Container(
                              width: 180,
                              child: btnOutline('Buy Now', () {
//                                changeScreen(context,Details());
                              }),
                            ),
                            Container(
                              width: 180,
                              child: btnFlat('Add to Cart', () async {
                                app.changeLoading();
                                print("All set loading");

                                // bool value =  await user.addToCard(product: widget.post, quantity: quantity);
                                // if(value){
                                //   print("Item added to cart");
                                //   _key.currentState.showSnackBar(
                                //       SnackBar(content: Text("Added to Cart!"))
                                //   );
                                //   user.reloadUserModel();
                                //   app.changeLoading();
                                //   return;
                                // } else{
                                //   print("Item NOT added to cart");
                                //
                                // }
                                print("lOADING SET TO FALSE");
                              }),
                            )
                          ],
                        ),
                        decoration: BoxDecoration(
                            color: white,
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: [
                              BoxShadow(
                                  blurRadius: 15,
                                  spreadRadius: 5,
                                  color: Color.fromRGBO(0, 0, 0, .05))
                            ]),
                      ),
                    ),
                    Align(
                      alignment: Alignment.center,
                      child: SizedBox(
                          width: 200,
                          height: 160,
                          child: Image.network(widget.post.data['image'])
                          // foodItem(
                          //     widget.post,
                          //     isProductPage: true,
                          //     onTapped: () {},
                          //     imgWidth: 250,
                          //     onLike: () {}),
                          ),
                    )
                  ],
                ),
              ),
            )
          ],
        ));
    return Scaffold(
      appBar: AppBar(
        title: Text('Product'),
      ),
      body: SingleChildScrollView(
        child: Container(
          color: Colors.white,
          padding: EdgeInsets.all(10),
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: Column(
            children: <Widget>[
              Container(
                height: 300,
                width: 300,
                child: Card(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      CircleAvatar(
                        backgroundImage:
                            NetworkImage(widget.post.data['image']),
                        radius: 50.0,
                      ),
                      Text('Name: ' + widget.post.data['name'] ?? 'no user'),
                      Text('Description: ' + widget.post.data['description'] ??
                          'User input missing'),
                      // Text('Price' + widget.post.data['price'].toString() ??
                      //     'User input missing')
//                  Text('Company Rep Name : ' + widget.post.data['companyRepName']),
//                  Text('Company Rep Surname: ' + widget.post.data['companyRepSurname']),
//                  Text('Contact Number : ' + widget.post.data['contactNumber']),
//                  Text('Email : ' + widget.post.data['email']),
//                  Text('Psycad Ambassador : ' + widget.post.data['psycadAmbNameAndSurname']),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
