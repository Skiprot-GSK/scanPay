import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ForgotPasswordPage extends StatelessWidget {
  TextEditingController editController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Forgot Password'),
      ),
      body: Container(
        margin: EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: editController,
              decoration: InputDecoration(
                  labelText: 'Email',
                  hintText: 'Enter email address',
                  border: OutlineInputBorder()),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              width: double.infinity,
              child: RaisedButton(
                color: Colors.black,
                onPressed: () {
                  resetPassword(context);
                },
                child: Text(
                  'Reset Password',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  void resetPassword(BuildContext context) async {
    if (editController.text.length == 0 || !editController.text.contains('@')) {
      print('Enter valid email');
      showDialog(
        context: context,
        builder: (context){
          return AlertDialog(
            title: Center(child: Text('Info', textScaleFactor: 2)),
            content: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Expanded(child: Text('Enter valid email',textAlign: TextAlign.center,)),
              ],
            ),
            actions: <Widget>[
              FlatButton(child: Text('Ok'), onPressed: () {Navigator.of(context).pop();}),
//            FlatButton(child: Text('Button 2'), onPressed: () {}),
            ],
          );},
      );
      return;
    }
    await FirebaseAuth.instance
        .sendPasswordResetEmail(email: editController.text);
    print(
        "Reset password link has been sent to your email please use it to change the password.");
    showDialog(
      context: context,
      builder: (context){
        return AlertDialog(
          title: Center(child: Text('Info', textScaleFactor: 2)),
          content: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Expanded(
                child: Text(
                  'Reset password link has been sent to your email please use it to change the password.',textAlign: TextAlign.center,),
              ),
            ],
          ),
          actions: <Widget>[
            FlatButton(child: Text('Ok'), onPressed: () {Navigator.of(context).pop();}),
//            FlatButton(child: Text('Button 2'), onPressed: () {}),
          ],
        );},
    );
  }
}
