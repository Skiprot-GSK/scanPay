package com.example.loyalty_points

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
