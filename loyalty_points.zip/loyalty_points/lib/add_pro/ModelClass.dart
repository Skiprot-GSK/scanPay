class Model {
  String barcode,name,netweight,price,key;
  Model({this.barcode,this.name,this.netweight,this.price,this.key});
}